console.log("Script Loaded");

// change theme work
let currentTheme = getTheme();

// Initial setup
document.addEventListener("DOMContentLoaded", () => {
    changePageTheme(currentTheme, currentTheme);
    changeTheme(); // Ensure initial theme setup
});

// Change theme function
function changeTheme() {
    // Set the listener to change theme button
    const changeThemeButton = document.querySelector("#theme_change_button");

    changeThemeButton.addEventListener("click", (event) => {
        console.log("Change theme button clicked");

        if (currentTheme === "dark") {
            // Change theme to light
            currentTheme = "light";
        } else {
            // Change theme to dark
            currentTheme = "dark";
        }

        changePageTheme(currentTheme, currentTheme === "light" ? "dark" : "light");
    });

    // Change the text of button
    document.querySelector("#theme_change_button span")
    .textContent = currentTheme === "light" ? "Dark" : "Light";
}

// Set theme to localStorage
function setTheme(theme) {
    localStorage.setItem("theme", theme);
}

// Get theme from localStorage
function getTheme() {
    let theme = localStorage.getItem("theme");
    return theme ? theme : "light"; // Default to light if theme is not set
}

// Change current page theme
// Change current page theme
function changePageTheme(theme, oldTheme) {
    // Update localStorage
    setTheme(theme);
    // Remove the current theme
    document.querySelector("html").classList.remove(oldTheme);
    // Set the new theme
    document.querySelector("html").classList.add(theme);

    // Change the text of button
    const buttonText = theme === "light" ? "Dark" : "Light";
    document.querySelector("#theme_change_button span").textContent = buttonText;
}

