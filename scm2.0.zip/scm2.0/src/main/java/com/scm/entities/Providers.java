package com.scm.entities;

public enum Providers {
    SELF,GOOGLE,FACEBOOK,TWITTER,LINKEDIN,GITHUB
}
