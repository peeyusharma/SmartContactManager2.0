package com.scm.services;

import com.scm.entities.User;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


public interface UserServices {

    User saveUser(User user);
    //here we are using optional so that we don't need use if and else
    Optional<User> getUserByID(String id);
    Optional<User> updateUser(User user);
    void deleteUser(String id);
    boolean isUserExist(String userId);
    boolean isUserExistByEmail(String email);
    List<User> getAllUsers();

    //add more methods here related user service[logic]
}
