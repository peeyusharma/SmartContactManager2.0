package com.scm.helpers;

public class AppConstants {

    public static  final  String APP_NAME = "SCM";
    public static  final  String ROLE_USER = "ROLE_USER";
}
