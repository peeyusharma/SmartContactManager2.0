package com.scm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
// npx tailwindcss -i ./src/main/resources/static/css/input.css -o
// ./src/main/resources/static/css/output.css --watch
}


//google client id - 1026987089968-24d5oueop5oha1jc0juai7f4ei9ni9f4.apps.googleusercontent.com

//google client secret - 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