package com.scm.Repositories;


import com.scm.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
//user repositories is used for interaction with database
// it has all the methods which is used for interaction with database

@Repository
public interface UserRepo extends JpaRepository<User,String> {

    //extra methods db related operations
    //custom query methods
    //custom finder methods

    Optional<User> findByEmail(String email);
//
//    @Query("select * from scm where name='name' & email='email'")
//    Optional<User> us=findbynameEmail(String name,String email )
    Optional<User> findByEmailAndPassword(String email, String password);
}
