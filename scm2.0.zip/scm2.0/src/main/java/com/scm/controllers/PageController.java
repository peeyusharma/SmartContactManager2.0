package com.scm.controllers;

import com.scm.entities.User;
import com.scm.forms.UserForm;
import com.scm.helpers.Message;
import com.scm.helpers.MessageType;
import com.scm.services.UserServices;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class PageController {

    @Autowired
    private UserServices userServices;

    @GetMapping("/")
    public String index() {
        return "redirect:/home";
    }

    @RequestMapping("/home")
    public String home(Model model) {
        System.out.println("Home Page!");
        model.addAttribute("name", " Peeyush Sharma");
        model.addAttribute("class", " 12th");
        model.addAttribute("subject", " Computer Science");
        return "home";
    }

    @RequestMapping("/about")
    public String aboutPage() {
        System.out.println("This is about Page!");
        return "about";
    }

    @RequestMapping("/services")
    public String servicesPage() {
        System.out.println("This is Service Page!");
        return "services";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/authenticate")
    public String authenticate(@RequestParam String email, @RequestParam String password) {
        System.out.println("Attempting to authenticate user with email: " + email);
        // Handle the authentication logic
        return "redirect:/user/dashboard"; // Redirect to dashboard on success
    }

    @GetMapping("/register")
    public String register(Model model) {
        UserForm userForm = new UserForm();
        model.addAttribute("userForm", userForm);
        return "register";
    }

    @PostMapping("/do-register")
    public String processRegister(@Valid @ModelAttribute UserForm userForm, BindingResult bindingResult, HttpSession session) {
        System.out.println("Registered...");
        System.out.println(userForm);

        if (bindingResult.hasErrors()) {
            return "register";
        }

        User user = new User();
        user.setName(userForm.getName());
        user.setEmail(userForm.getEmail());
        user.setPassword(userForm.getPassword());
        user.setAbout(userForm.getAbout());
        user.setPhoneNumber(userForm.getPhoneNumber());
        user.setProfilePic("https://www.facebook.com/p/Stylish-Dp-For-BOYS-100069676478141/");

        User savedUser = userServices.saveUser(user);
        System.out.println("User saved!");

        Message message = Message.builder().content("Registration Successful!").type(MessageType.green).build();
        session.setAttribute("message", message);

        return "redirect:/register";
    }
}
